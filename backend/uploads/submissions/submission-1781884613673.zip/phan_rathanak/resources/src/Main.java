// Run the MultithreadedSort application
void main() {
    MultithreadedSort.main(new String[0]);
}
