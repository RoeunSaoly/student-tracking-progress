import java.util.Arrays;
import java.util.Random;

public class MultithreadedSort {

    // Global arrays as per requirements
    public static int[] originalArray;
    public static int[] singleThreadArray;
    public static int[] multiThreadArray;

    public static void main(String[] args) {
        int[] inputSizes = {10000, 100000, 500000, 1000000};
        
        System.out.println("Starting Sorting Performance Comparison...\n");

        for (int size : inputSizes) {
            System.out.println("=================================================");
            System.out.println("Array Size: " + size);
            System.out.println("=================================================");

            // 1. Initialize global arrays
            initializeArrays(size);

            // 2. Perform Single-threaded Sort
            long singleThreadTime = runSingleThreadedSort();
            System.out.printf("Single-threaded sort time: %.2f ms\n", (singleThreadTime / 1_000_000.0));

            // 3. Perform Multi-threaded Sort
            long multiThreadTime = runMultiThreadedSort();
            System.out.printf("Multi-threaded sort time:  %.2f ms\n", (multiThreadTime / 1_000_000.0));

            // 4. Verify Correctness
            boolean isCorrect = Arrays.equals(singleThreadArray, multiThreadArray);
            System.out.println("Sort correctness verified: " + (isCorrect ? "PASSED" : "FAILED"));
            System.out.println();
        }
    }

    /**
     * Initializes the arrays with random integers.
     */
    private static void initializeArrays(int size) {
        originalArray = new int[size];
        singleThreadArray = new int[size];
        multiThreadArray = new int[size];

        Random random = new Random();
        for (int i = 0; i < size; i++) {
            originalArray[i] = random.nextInt(size * 10); // Random numbers
        }

        // Copy original array to ensure both methods sort the exact same data
        System.arraycopy(originalArray, 0, singleThreadArray, 0, size);
        System.arraycopy(originalArray, 0, multiThreadArray, 0, size);
    }

    /**
     * Executes the standard single-threaded sort and returns the execution time.
     */
    private static long runSingleThreadedSort() {
        long startTime = System.nanoTime();
        
        // Single-threaded sort of the entire array
        Arrays.sort(singleThreadArray);
        
        long endTime = System.nanoTime();
        return endTime - startTime;
    }

    /**
     * Executes the multithreaded sort using 3 threads and returns the execution time.
     */
    private static long runMultiThreadedSort() {
        long startTime = System.nanoTime();

        int mid = multiThreadArray.length / 2;

        // Create thread 1 to sort the first half (0 to mid)
        SortingThread thread1 = new SortingThread(0, mid);
        
        // Create thread 2 to sort the second half (mid to end)
        SortingThread thread2 = new SortingThread(mid, multiThreadArray.length);

        // Start both threads concurrently
        thread1.start();
        thread2.start();

        try {
            // Main thread waits for both sorting threads to finish
            thread1.join();
            thread2.join();

            // Create thread 3 to merge the two sorted halves
            MergingThread mergeThread = new MergingThread(0, mid, multiThreadArray.length);
            
            // Start the merging thread
            mergeThread.start();
            
            // Main thread waits for the merging thread to finish
            mergeThread.join();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long endTime = System.nanoTime();
        return endTime - startTime;
    }

    // ==========================================
    // Classes for Threads
    // ==========================================

    /**
     * Thread responsible for sorting a specific portion of the global multiThreadArray.
     */
    static class SortingThread extends Thread {
        private final int startIndex;
        private final int endIndex;

        public SortingThread(int startIndex, int endIndex) {
            this.startIndex = startIndex;
            this.endIndex = endIndex;
        }

        @Override
        public void run() {
            // Sort the designated sub-array using Java's built-in sort
            Arrays.sort(multiThreadArray, startIndex, endIndex);
        }
    }

    /**
     * Thread responsible for merging two sorted halves of the global multiThreadArray.
     */
    static class MergingThread extends Thread {
        private final int left;
        private final int mid;
        private final int right;

        public MergingThread(int left, int mid, int right) {
            this.left = left;
            this.mid = mid;
            this.right = right;
        }

        @Override
        public void run() {
            // Temporary array for holding the merged result
            int[] temp = new int[right - left];
            int i = left;     // Index for the left half
            int j = mid;      // Index for the right half
            int k = 0;        // Index for the temp array

            // Merge elements from both halves in sorted order
            while (i < mid && j < right) {
                if (multiThreadArray[i] <= multiThreadArray[j]) {
                    temp[k++] = multiThreadArray[i++];
                } else {
                    temp[k++] = multiThreadArray[j++];
                }
            }

            // Copy any remaining elements from the left half
            while (i < mid) {
                temp[k++] = multiThreadArray[i++];
            }

            // Copy any remaining elements from the right half
            while (j < right) {
                temp[k++] = multiThreadArray[j++];
            }

            // Copy the sorted temp array back into the global multiThreadArray
            System.arraycopy(temp, 0, multiThreadArray, left, temp.length);
        }
    }
}
